load('autorrhy.mat');
load('autorrox.mat');
load('autorrall.mat');
figure(1);
plot(autorrhy(:,1),autorrhy(:,2),'LineWidth',1);
set(gca,'LineWidth',1,'FontSize',24,'FontWeight','normal','FontName','Times')
set(get(gca,'XLabel'),'String','Time(fs)','FontSize',20,'FontWeight','bold','FontName','Times')
set(get(gca,'YLabel'),'String','C_{VV}^{H}(t)','FontSize',20,'FontWeight','bold','FontName','Times')
set(gcf,'Position',[1 1 round(1000) round(1000)]) 
xlim([0 1000]);
savefig('vhy.fig');
pause
close;
figure(2);
plot(autorrox(:,1),autorrox(:,2),'LineWidth',1);
set(gca,'LineWidth',1,'FontSize',24,'FontWeight','normal','FontName','Times')
set(get(gca,'XLabel'),'String','Time(fs)','FontSize',20,'FontWeight','bold','FontName','Times')
set(get(gca,'YLabel'),'String','C_{VV}^{O}(t)','FontSize',20,'FontWeight','bold','FontName','Times')
set(gcf,'Position',[1 1 round(1000) round(1000)]) 
xlim([0 1000]);
savefig('vox.fig');
pause
close;
figure(3);
plot(autorrall(:,1),autorrall(:,2),'LineWidth',1);
set(gca,'LineWidth',1,'FontSize',24,'FontWeight','normal','FontName','Times')
set(get(gca,'XLabel'),'String','Time(fs)','FontSize',20,'FontWeight','bold','FontName','Times')
set(get(gca,'YLabel'),'String','C_{VV}(t)','FontSize',20,'FontWeight','bold','FontName','Times')
set(gcf,'Position',[1 1 round(1000) round(1000)]) 
xlim([0 1000]);
savefig('vall.fig');
pause
close;