function [autocorr]=autorr(velfnl,n,nmax,dt,nat)
    tic
    for i=1:size(velfnl,1)
        sum=0;
        for j=1:nat
            sum=sum+dot(velfnl(i,3*j-2:3*j),velfnl(i,3*j-2:3*j));
        end
        avgvel(i,1)=sum/nat;
    end
    clear sum;
    autocorr=zeros(nmax+1,2);
    autocorr(:,1)=[0:dt:(size(autocorr,1)-1)*dt]';
    %h = waitbar(0,'Please wait...');
    for i=1:n-nmax
      for j=i:i+nmax
          sum=0;
          for k=1:nat
              sum=sum+(velfnl(i,3*k-2)*velfnl(j,3*k-2)+velfnl(i,3*k-1)*velfnl(j,3*k-1)+velfnl(i,3*k)*velfnl(j,3*k));
          end
          sum=sum/(avgvel(i,1)*nat);
          autocorr(j-i+1,2)=autocorr(j-i+1,2)+sum;
      end
    end
    %close(h);
    autocorr(:,2)=autocorr(:,2)/autocorr(1,2);
    toc