% script written to calculate the translational diffusion coefficient
tic
clear all;
load('velfnlhy.mat');
load('velfnlox.mat');
load('trjfnlhy.mat');
load('trjfnlox.mat');
velfnlhy=1.00797*velfnlhy;
trjfnlhy=1.00797*trjfnlhy;
velfnlox=15.9994*velfnlox;
trjfnlox=15.9994*trjfnlox;
% store velocity for molecules as mass weighted of hydrogen and oxygen
for i=1:size(velfnlhy,1)
    for j=1:size(velfnlox,2)/3
        velfnlmol(i,3*j-2:3*j)=velfnlhy(i,6*j-5:6*j-3)+velfnlhy(i,6*j-2:6*j)+velfnlox(i,3*j-2:3*j);
        trjfnlmol(i,3*j-2:3*j)=trjfnlhy(i,6*j-5:6*j-3)+trjfnlhy(i,6*j-2:6*j)+trjfnlox(i,3*j-2:3*j);
    end
end
velfnlmol=velfnlmol/(2*1.00797+15.9994);
trjfnlmol=trjfnlmol/(2*1.00797+15.9994);
save('velfnlmol.mat','velfnlmol');
save('trjfnlmol.mat','trjfnlmol');
toc