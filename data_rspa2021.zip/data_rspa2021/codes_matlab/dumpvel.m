clear all;
tic
velfnl=[];
trjfnl=[];
for in=0:2:4000
    flnm=strcat('dump.',int2str(in),'.velhy');
    vlh=dlmread(flnm,'',9,0);
    for i=1:size(vlh,1)
       vel(1,3*i-2:3*i)=vlh(i,7:9);
       trj(1,3*i-2:3*i)=vlh(i,4:6);
    end
    velfnl=vertcat(velfnl,vel);
    trjfnl=vertcat(trjfnl,trj);
    clear vel vlh trj;
end
velfnlhy=velfnl;
trjfnlhy=trjfnl;
save('velfnlhy.mat','velfnlhy');
save('trjfnlhy.mat','trjfnlhy');
clear all;
velfnl=[];
trjfnl=[];
for in=0:2:4000
    flnm=strcat('dump.',int2str(in),'.velox');
    vlo=dlmread(flnm,'',9,0);
    for i=1:size(vlo,1)
       vel(1,3*i-2:3*i)=vlo(i,7:9);
       trj(1,3*i-2:3*i)=vlo(i,4:6);
    end
    velfnl=vertcat(velfnl,vel);
    trjfnl=vertcat(trjfnl,trj);
    clear vel vlo trj;
end
velfnlox=velfnl;
trjfnlox=trjfnl;
save('velfnlox.mat','velfnlox');
save('trjfnlox.mat','trjfnlox');
clear all;
load('velfnlhy.mat');
load('velfnlox.mat');
velfnlall=horzcat(velfnlhy,velfnlox);
save('velfnlall.mat','velfnlall');
toc