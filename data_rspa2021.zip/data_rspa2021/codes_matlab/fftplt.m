load('ffthy.mat');
load('fftox.mat');
load('fftall.mat');
figure(1);
plot(ffthy(:,1),ffthy(:,2),'g','LineWidth',1);
set(gca,'LineWidth',1,'FontSize',24,'FontWeight','normal','FontName','Times')
set(get(gca,'XLabel'),'String','\omega(cm^{-1})','FontSize',20,'FontWeight','bold','FontName','Times')
set(get(gca,'YLabel'),'String','Power Spectrum(Arb. Units)','FontSize',20,'FontWeight','bold','FontName','Times')
set(gcf,'Position',[1 1 round(1000) round(1000)]) 
savefig('vhyfft.fig');
pause
close;
figure(2);
plot(fftox(:,1),fftox(:,2),'g','LineWidth',1);
set(gca,'LineWidth',1,'FontSize',24,'FontWeight','normal','FontName','Times')
set(get(gca,'XLabel'),'String','\omega(cm^{-1})','FontSize',20,'FontWeight','bold','FontName','Times')
set(get(gca,'YLabel'),'String','Power Spectrum(Arb. Units)','FontSize',20,'FontWeight','bold','FontName','Times')
set(gcf,'Position',[1 1 round(1000) round(1000)]) 
savefig('voxfft.fig');
pause
close;
figure(3);
plot(fftall(:,1),fftall(:,2),'g','LineWidth',1);
set(gca,'LineWidth',1,'FontSize',24,'FontWeight','normal','FontName','Times')
set(get(gca,'XLabel'),'String','\omega(cm^{-1})','FontSize',20,'FontWeight','bold','FontName','Times')
set(get(gca,'YLabel'),'String','Power Spectrum(Arb. Units)','FontSize',20,'FontWeight','bold','FontName','Times')
set(gcf,'Position',[1 1 round(1000) round(1000)]) 
savefig('vallfft.fig');
pause
close;
