% script written to calculate the eigen values of translational, rotational
% and translational rotational tensor
tic
load('velfnlmol.mat');
load('omgfnlall.mat');
a=omgfnlall;
b=omgfnlall;
dt=1;
n=2001;
nmol=800;
nmax=1000;
crsscorr=zeros(nmax+1,3);
crsscorr(:,1)=[0:dt:(size(crsscorr,1)-1)*dt]';
autocorr=zeros(3,3,nmax+1);
for i=1:n-nmax
  for j=i:i+nmax
      sum=0;
      for k=1:nmol
          sum=sum+kron(a(i,3*k-2:3*k)',b(j,3*k-2:3*k));
      end
      sum=sum/(nmol);
      autocorr(:,:,j-i+1)=autocorr(:,:,j-i+1)+sum;
  end
end
autocorr=autocorr/(n-nmax);
for i=1:nmax+1
    egvl=[];
%     sum=0;
%     for k=1:nmol
%         sum=sum+kron(a(1,3*k-2:3*k)',b(i,3*k-2:3*k));
%     end
%     sum=sum/nmol;
    egvl=eig(autocorr(:,:,i))';
    crsscorr(i,2:4)=egvl;
end
crsscorromg=crsscorr;
save('crsscorromg.mat','crsscorromg');
toc