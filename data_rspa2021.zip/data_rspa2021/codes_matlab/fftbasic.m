function [rslt]=fftbasic(autorr)  
    % This script is written to calculate the fft of a given function upto the
    % available time data. Specifically wriiten for purpose of fft of
    % autocorrelation function of any physical quantity (Here dipole moment)
    % This responds to the basic principle as I(w)=int_0^inf(autocorrelation
    % function)cos(wt)dt 
    %load('autocorr.mat');
    dt=1; % timestep in terms of fs
    % Initially we assume to determine pattern upto 120THz (nearly 4000 cm-1)
    % we are taking interval of 0.025 THz.
    %fnl=120; %final frequency in terms of THz
    %intvl=0.025; % interval of frequency in terms of THz
    fnl=4000; % in terms of cm-1
    %intvl=0.8; % interval of frequency in terms of cm-1
    h = waitbar(0,'Please wait...');
    ini=clock;
    ini=60*ini(1,3)+ini(1,4);
    k=1;
    N=200*size(autorr,1);
    Fmax=N*(fnl*(2.0*pi*10^(-15)*29979245800.0));
    for i=0:floor(Fmax)
        omg=i/N; % omega in terms of rad/fs
        sum=0;
        for j=1:size(autorr,1)
    %         sum=sum+dt*(10^(-15))*autorr(j,1)*cos(2*pi*i*dt*j*0.001);
              sum=sum+autorr(j,2)*cos(omg*autorr(j,1));
        end
        rslt(k,1)=omg*10^15/(2*pi*29979245800.0);
        rslt(k,2)=sum;
        k=k+1;
        prs=i/floor(Fmax)*100;
        prs=floor(prs);
        fin=clock;
        fin=60*fin(1,3)+fin(1,4);
        fg=fin-ini;
        sft=strcat('Time elapsed:',int2str(fg),'mins::Please wait::Progress:',int2str(prs),'%%');
        waitbar(i/floor(Fmax),h,sprintf(sft));
    end
    close(h);