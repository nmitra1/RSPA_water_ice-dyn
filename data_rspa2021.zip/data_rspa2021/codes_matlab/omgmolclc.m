tic;
clear all;
%script written to calculate the angular velocity of each molecule using 
% classical mechanics relation L=Iw where I is moment of inertia tensor 
% elements of M.I. tensor follow omega_chunk.cpp from lammps while L=rx(mv)
load('trjfnlhy.mat');
load('trjfnlmol.mat');
load('trjfnlox.mat');
load('velfnlox.mat');
load('velfnlhy.mat');
nop=size(velfnlox,2)/3; % here no. of molecules
mh=1.00797; % mass of hydrogen
mo=15.9994; % mass of oxygen
mss=[mh mh mo];
velfnlhy=mh*velfnlhy;
velfnlox=mo*velfnlox;
omgfnl=[];
for i=1:size(velfnlox,1)
    omghrz=[];
    for j=1:nop
        molvel=[velfnlhy(i,6*j-5:6*j) velfnlox(i,3*j-2:3*j)];
        molcom=[trjfnlhy(i,6*j-5:6*j) trjfnlox(i,3*j-2:3*j)]-[trjfnlmol(i,3*j-2:3*j) trjfnlmol(i,3*j-2:3*j) trjfnlmol(i,3*j-2:3*j)];
        % calculation of angular momentum and moment of inertia
        lsum=zeros(3,1);
        misum=zeros(3);
        for k=1:size(molvel,2)/3
            msum=zeros(3);
            lsum=lsum+cross(molcom(1,3*k-2:3*k),molvel(1,3*k-2:3*k))';
            msum(1,1)=mss(k)*dot(molcom(3*k-1:3*k),molcom(3*k-1:3*k));
            msum(2,2)=mss(k)*dot(molcom(3*k-2:2:3*k),molcom(3*k-2:2:3*k));
            msum(3,3)=mss(k)*dot(molcom(3*k-2:3*k-1),molcom(3*k-2:3*k-1));
            msum(1,2)=-mss(k)*molcom(3*k-2)*molcom(3*k-1);
            msum(2,1)=msum(1,2);
            msum(1,3)=-mss(k)*molcom(3*k-2)*molcom(3*k);
            msum(3,1)=msum(1,3);
            msum(2,3)=-mss(k)*molcom(3*k-1)*molcom(3*k);
            msum(3,2)=msum(2,3);
            misum=misum+msum;
        end
        omg=misum\lsum;
        omghrz=horzcat(omghrz,omg');
    end
    omgfnl=vertcat(omgfnl,omghrz);
end
omgfnlall=omgfnl;
save('omgfnlall.mat','omgfnlall');
toc;
