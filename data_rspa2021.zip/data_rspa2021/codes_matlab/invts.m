clear all;
close all;
load('crsscorrvel.mat');
data=crsscorrvel;
data(:,2:4)=abs(data(:,2:4));
for i=1:size(data,1)
    invrnts(i,1)=abs(data(i,2)+data(i,3)+data(i,4));
    invrnts(i,2)=abs(data(i,2)*data(i,3)+data(i,3)*data(i,4)+data(i,2)*data(i,4));
    invrnts(i,3)=abs(data(i,2)*data(i,3)*data(i,4));
    invrnts(i,4)=(data(i,2)+data(i,3)+data(i,4));
    invrnts(i,5)=(data(i,2)*data(i,3)+data(i,3)*data(i,4)+data(i,2)*data(i,4));
    invrnts(i,6)=(data(i,2)*data(i,3)*data(i,4));    
end
figure(1)
plot(data(:,1),invrnts(:,1))
% savefig('eye1velabs.fig');
figure(2)
plot(data(:,1),invrnts(:,2))
% savefig('eye2velabs.fig');
figure(3)
plot(data(:,1),invrnts(:,3))
% savefig('eye3velabs.fig');
figure(4)
plot(data(:,1),invrnts(:,4))
% savefig('eye1vel.fig');
figure(5)
plot(data(:,1),invrnts(:,5))
% savefig('eye2vel.fig');
figure(6)
plot(data(:,1),invrnts(:,6))
% savefig('eye3vel.fig');